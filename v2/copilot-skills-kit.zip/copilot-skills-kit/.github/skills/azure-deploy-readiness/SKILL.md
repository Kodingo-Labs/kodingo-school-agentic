---
name: azure-deploy-readiness
description: Prepara y verifica el despliegue del microservicio Quarkus en Azure (imagen de contenedor, health probes, configuración y secretos, identidad administrada, observabilidad, recursos, escalado, CI/CD y rollback). Úsala cuando se pida desplegar en Azure, preparar la infraestructura, el Dockerfile o el pipeline, o revisar si el servicio está listo para producción.
---

# Azure deploy readiness

## Objetivo

Dejar el servicio listo para producción en Azure con un checklist verificable y los artefactos de despliegue necesarios.

**Destino Azure configurado: `{{AZURE_TARGET}}`**

Si el destino es `por-definir`, empieza con la sección "Selección de destino" y pide confirmación antes de generar artefactos.

## Entradas

- `docs/migracion/01-arquitectura.md` (integraciones y configuración), `05-migracion-quarkus.md` y `07-paridad.md`.

## Restricciones

- No escribir secretos en el repositorio ni en los artefactos.
- Preferir autenticación sin contraseña (Managed Identity / Workload Identity).
- Los artefactos que se generen (Dockerfile, manifiestos, IaC, pipeline) se proponen primero y se aplican con confirmación.

## Selección de destino (si no está definido)

Compara para este servicio: **Azure Container Apps** (serverless, revisiones y escalado KEDA, menor operación), **AKS** (máximo control, requiere equipo de plataforma) y **App Service for Containers** (simple, menos flexible). Criterios: operación, costo, escalado, networking privado, estándares de la organización.

## Checklist

1. **Imagen de contenedor**
   - Dockerfile basado en los generados por Quarkus (`src/main/docker/Dockerfile.jvm` o `.native`), usuario no root, imagen base soportada.
   - Decisión **JVM vs nativo** justificada (tiempo de build, compatibilidad de librerías, arranque, memoria).
   - Publicación en Azure Container Registry con tags inmutables (commit SHA).
2. **Health probes**: liveness → `/q/health/live`, readiness → `/q/health/ready`, startup probe si el arranque es lento; health checks de BD y dependencias críticas en readiness.
3. **Configuración y secretos**
   - Configuración por variables de entorno (convención de Quarkus: `QUARKUS_DATASOURCE_USERNAME`...).
   - Secretos en **Azure Key Vault** (referencias de Key Vault, CSI Secrets Store en AKS o extensión de Quarkiverse `[VERIFICAR]`).
   - Configuración compartida en Azure App Configuration, si aplica.
4. **Identidad**: Managed Identity (Workload Identity en AKS) para BD, Key Vault, Storage y Service Bus. Roles con mínimo privilegio.
5. **Datos**: Azure SQL / PostgreSQL Flexible Server, conexión passwordless si es posible, pool de conexiones dimensionado, migraciones (Flyway/Liquibase) ejecutadas de forma controlada.
6. **Observabilidad**: OpenTelemetry → Azure Monitor / Application Insights (validar compatibilidad del agente Java de App Insights con Quarkus `[VERIFICAR]`), logs en JSON con traceId, métricas, dashboards y alertas (errores 5xx, latencia p95, reinicios).
7. **Recursos y JVM**: requests/limits de CPU y memoria, `-XX:MaxRAMPercentage`, pruebas de carga básicas.
8. **Escalado**: reglas (HTTP concurrency, CPU, KEDA por cola), mínimo de réplicas para alta disponibilidad.
9. **Red y seguridad**: ingress/HTTPS, private endpoints, CORS, escaneo de vulnerabilidades de la imagen y dependencias.
10. **CI/CD** (GitHub Actions o Azure DevOps): build → tests unitarios → tests de contrato → análisis estático → build de imagen → escaneo → push a ACR → deploy por ambiente (dev → qa → prod) con aprobaciones.
11. **Estrategia de liberación y rollback**: blue/green, canary o revisiones con división de tráfico; criterios de rollback definidos y probados.
12. **Convivencia y corte**: plan para ejecutar la versión Spring y la Quarkus en paralelo, redirección de tráfico y retiro del servicio anterior.

## Entregables

- `docs/migracion/08-despliegue-azure.md`: destino elegido y justificación, checklist con estado (✅ / ⚠️ / ❌), artefactos propuestos, variables y secretos requeridos (solo nombres), plan de liberación y rollback, runbook básico de operación.
- Artefactos propuestos (con confirmación): Dockerfile, manifiestos o IaC (Bicep/Terraform), pipeline.

## Checklist de salida

- [ ] Ningún secreto en el repositorio.
- [ ] Probes configuradas y probadas.
- [ ] Rollback definido y probado en un ambiente no productivo.
