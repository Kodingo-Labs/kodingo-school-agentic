---
name: migration-parity-check
description: Verifica que el servicio migrado a Quarkus sea funcionalmente equivalente al original en Spring Boot, comparando tests de contrato, OpenAPI, respuestas de error, configuración y observabilidad, y emite un veredicto de paridad. Úsala después de la migración o cuando se pida validar, comparar o certificar la versión Quarkus.
---

# Migration parity check

## Objetivo

Demostrar con evidencia objetiva que la versión Quarkus se comporta igual que la versión Spring, o listar exactamente dónde difiere.

## Entradas

- `docs/migracion/02-api-y-logica.md`, `openapi-actual.yaml`, `03-plan-tests.md` y `05-migracion-quarkus.md`.
- La suite de contrato (`@Tag("contract")`) creada por `characterization-tests`.
- Ambas versiones del servicio ejecutándose (o instrucciones para levantarlas).

## Pasos

1. **Build y tests unitarios** de la versión Quarkus: todos deben pasar. Lista los que se portaron o reescribieron.
2. **Suite de contrato contra ambas versiones**:
   - `-Dcontract.baseUrl=<url-spring>` y `-Dcontract.baseUrl=<url-quarkus>`.
   - Compara resultados test por test; cualquier diferencia es un hallazgo.
3. **Diff de contrato OpenAPI**: exporta el OpenAPI de Quarkus (`/q/openapi`) y compáralo con `openapi-actual.yaml` (por ejemplo con `oasdiff`). Clasifica los cambios como breaking o no breaking.
4. **Paridad de respuestas**: status codes, headers (Content-Type, CORS, cache), formato de fechas y números, campos nulos u omitidos, orden y paginación, y **cuerpo de error** en cada caso.
5. **Paridad de configuración**: cada propiedad y variable de entorno del original tiene equivalente y el mismo valor efectivo por perfil.
6. **Paridad de integraciones**: los mismos timeouts, reintentos y comportamiento ante fallos de dependencias externas.
7. **Seguridad**: los mismos endpoints protegidos, roles y respuestas 401/403.
8. **Observabilidad**: health (`/q/health/live`, `/q/health/ready`), métricas, trazas y logs con correlación.
9. **Smoke de rendimiento** (orientativo): tiempo de arranque, memoria en reposo y latencia p95 de los endpoints principales en ambas versiones.

## Formato de diferencias

| ID | Área | Endpoint / propiedad | Spring | Quarkus | Breaking | Acción |
|---|---|---|---|---|---|---|

## Veredicto

- **APTO**: sin diferencias breaking.
- **APTO CON OBSERVACIONES**: diferencias no breaking documentadas y aceptadas.
- **NO APTO**: al menos una diferencia breaking sin resolver.

## Entregables

- `docs/migracion/07-paridad.md`: resumen y veredicto, resultados por paso, tabla de diferencias, comparación de rendimiento y acciones pendientes.

## Checklist de salida

- [ ] La suite de contrato se ejecutó contra ambas versiones.
- [ ] El diff de OpenAPI está adjunto y clasificado.
- [ ] El veredicto está justificado con evidencia.
