---
name: quarkus-migration-assessment
description: Genera el inventario de librerías, anotaciones, objetos y configuración que deben migrarse de Spring Boot a Quarkus, con su equivalente, los riesgos de la migración y un plan por fases para el agente migrador. Úsala cuando se pida evaluar, planificar o estimar la migración a Quarkus.
---

# Quarkus migration assessment

## Objetivo

Construir el plan de migración que consumirá el agente migrador: qué cambia, por qué, con qué riesgo y en qué orden.

## Entradas

- `docs/migracion/01-arquitectura.md`, `02-api-y-logica.md`, `03-plan-tests.md` y `04-deuda-tecnica.md`.

## Restricciones

- Solo análisis: no modificar código.
- Versión objetivo: la **LTS vigente de Quarkus**. Verifica la versión actual y las extensiones en la documentación oficial (quarkus.io/extensions) antes de afirmar nombres o disponibilidad; márcalo `[VERIFICAR]` si no puedes confirmarlo.

## Pasos

1. **Decisión de estrategia** (documentar pros y contras):
   - **APIs nativas de Quarkus** (JAX-RS, CDI, MicroProfile, Panache): recomendado a mediano plazo.
   - **Extensiones de compatibilidad Spring** (`quarkus-spring-web`, `quarkus-spring-di`, `quarkus-spring-data-jpa`, `quarkus-spring-boot-properties`, `quarkus-spring-security`, `quarkus-spring-cache`, `quarkus-spring-scheduled`): migración más rápida, pero cubren un subconjunto de funcionalidad y dejan deuda. Verifica su vigencia actual.
2. **Inventario de dependencias**: tabla dependencia actual → extensión Quarkus → notas → riesgo.
3. **Inventario de código**: busca cada patrón de la tabla de mapeo y lista **cada ocurrencia** con `archivo:línea`, agrupada por tipo.
4. **Configuración**: mapear cada propiedad de `application*.yml` a su equivalente en `application.properties` de Quarkus, y perfiles a `%dev`, `%test` y `%prod`.
5. **Impacto en tests**: qué tests de `03-plan-tests.md` son portables y cuáles deben reescribirse (`@QuarkusTest`, `@InjectMock`).
6. **Registro de riesgos**.
7. **Plan por fases para el agente migrador**.

## Tabla de mapeo de referencia

### Dependencias

| Spring | Quarkus |
|---|---|
| `spring-boot-starter-web` | `quarkus-rest` + `quarkus-rest-jackson` |
| `spring-boot-starter-validation` | `quarkus-hibernate-validator` |
| `spring-boot-starter-data-jpa` | `quarkus-hibernate-orm-panache` (o `quarkus-spring-data-jpa`) + driver `quarkus-jdbc-*` |
| Flyway / Liquibase | `quarkus-flyway` / `quarkus-liquibase` |
| `spring-boot-starter-security` / OAuth2 Resource Server | `quarkus-oidc` / `quarkus-smallrye-jwt` |
| `spring-boot-starter-actuator` | `quarkus-smallrye-health` + `quarkus-micrometer-registry-prometheus` |
| springdoc-openapi | `quarkus-smallrye-openapi` |
| RestTemplate / WebClient / OpenFeign | `quarkus-rest-client` + `quarkus-rest-client-jackson` |
| Spring Kafka / Spring AMQP | `quarkus-messaging-kafka` / `quarkus-messaging-rabbitmq` |
| SDKs de Azure (Service Bus, Blob, Key Vault, App Configuration) | Extensiones de Quarkiverse Azure `[VERIFICAR]` o SDK directo |
| `spring-boot-starter-cache` / Redis | `quarkus-cache` / `quarkus-redis-client` |
| Resilience4j | `quarkus-smallrye-fault-tolerance` |
| Micrometer Tracing / Sleuth | `quarkus-opentelemetry` |
| Logback / Log4j2 config | Logging de Quarkus (JBoss LogManager), `quarkus-logging-json` |
| `spring-boot-starter-test` | `quarkus-junit5`, `quarkus-junit5-mockito`, `rest-assured` |
| MapStruct | Compatible; usar `componentModel = "cdi"` / `jakarta-cdi` |
| Lombok | Compatible (revisar `@SneakyThrows` y builders en entidades) |

### Anotaciones y objetos

| Spring | Quarkus |
|---|---|
| `@RestController`, `@RequestMapping`, `@GetMapping`... | `@Path`, `@GET`, `@POST`, `@Produces`, `@Consumes` |
| `@PathVariable`, `@RequestParam`, `@RequestHeader` | `@PathParam`/`@RestPath`, `@QueryParam`/`@RestQuery`, `@HeaderParam`/`@RestHeader` |
| `ResponseEntity<T>` | `Response` / `RestResponse<T>` |
| `@Service`, `@Component` | `@ApplicationScoped` |
| `@Repository` (Spring Data) | `PanacheRepository<T>` + `@ApplicationScoped` |
| `@Configuration` + `@Bean` | Bean CDI con métodos `@Produces` |
| `@Autowired` | `@Inject` o constructor |
| `@Value` | `@ConfigProperty` |
| `@ConfigurationProperties` | `@ConfigMapping` |
| `@Profile` | Perfiles `%dev/%prod`, `@IfBuildProfile` |
| `@ConditionalOnProperty` y demás `@Conditional*` | `@IfBuildProperty`/`@LookupIfProperty` (**se resuelve en build time**) |
| `@ControllerAdvice` + `@ExceptionHandler` | `ExceptionMapper<T>` / `@ServerExceptionMapper` |
| `@Transactional` (Spring) | `jakarta.transaction.Transactional` (sin `readOnly`; revisar propagación y rollback) |
| `@Async` | `ManagedExecutor`, `Uni`/`CompletionStage` |
| `@Scheduled` | `io.quarkus.scheduler.Scheduled` |
| `ApplicationEvent` / `@EventListener` | Eventos CDI (`Event<T>`, `@Observes`) |
| `CommandLineRunner` / `ApplicationRunner` | `@Observes StartupEvent` |
| `Filter`, `HandlerInterceptor` | `ContainerRequestFilter` / `@ServerRequestFilter` |
| `@Aspect` (Spring AOP) | Interceptores CDI (`@InterceptorBinding`) |
| `@PreAuthorize`, `@Secured` | `@RolesAllowed`, `@PermissionsAllowed` |
| Derived queries, `Pageable`, `Specification` | Métodos Panache, `Page`, Criteria API (riesgo si hay Specifications complejas) |
| `javax.*` (Boot 2) | `jakarta.*` |
| `@MockBean` en tests | `@InjectMock` |

## Riesgos que se deben buscar activamente

1. **Librerías internas/corporativas** construidas sobre Spring (starters, auto-configuración): sin equivalente directo. Suele ser el riesgo principal.
2. **Spring Boot 2 → `javax` a `jakarta`**: cambio de namespace en todo el código.
3. **Build time vs runtime**: CDI de Quarkus resuelve beans al compilar. `@Conditional`, registro dinámico de beans y `getBean` en runtime no funcionan igual.
4. **Semántica de transacciones** diferente (propagación, `readOnly`, rollback con checked exceptions).
5. **Formato de respuestas de error** y serialización Jackson (fechas, nulos, propiedades desconocidas, naming): los consumidores pueden romperse.
6. **Hibernate**: diferencias de versión en JPQL, tipos y generadores de ID.
7. **Seguridad**: expresiones SpEL de `@PreAuthorize` sin equivalente directo.
8. **Imagen nativa (si se evalúa)**: reflexión, proxies dinámicos y recursos requieren registro explícito.
9. **Hilos**: en Quarkus REST, los métodos que devuelven `Uni`/`Multi` se ejecutan en el event loop; el código bloqueante debe ir en worker threads (`@Blocking`).
10. **Tests dependientes de Spring**, que se pierden al migrar.
11. **Nombres de propiedades de configuración** y variables de entorno ya usadas en los despliegues.

## Formato del registro de riesgos

| ID | Riesgo | Evidencia (`archivo:línea`) | Probabilidad | Impacto | Mitigación | Responsable |
|---|---|---|---|---|---|---|

## Plan por fases (para el agente migrador)

1. Preparación: deuda técnica marcada ANTES y red de tests en verde.
2. Build: nuevo `pom.xml` con BOM de Quarkus, extensiones y plugin.
3. Configuración: `application.properties` y perfiles.
4. Capa de datos: entidades y repositorios.
5. Servicios y DI.
6. Capa REST, manejo de errores y seguridad.
7. Integraciones (clientes REST, mensajería, caché, scheduler).
8. Observabilidad (health, métricas, trazas, logs).
9. Tests: portar tests dependientes de Spring y ejecutar la suite de contrato.

Cada fase indica archivos afectados, criterio de terminado y validación.

## Entregables

- `docs/migracion/05-migracion-quarkus.md`: resumen ejecutivo, estrategia elegida, versión objetivo, inventario de dependencias, inventario de código con ocurrencias, mapeo de configuración, impacto en tests, registro de riesgos, plan por fases, estimación (S/M/L por fase) y preguntas abiertas.

## Checklist de salida

- [ ] Cada dependencia tiene destino o está marcada como "sin equivalente" con plan.
- [ ] Cada ocurrencia de anotación Spring está inventariada.
- [ ] Las librerías internas tienen análisis propio.
- [ ] Riesgos con evidencia y mitigación.
