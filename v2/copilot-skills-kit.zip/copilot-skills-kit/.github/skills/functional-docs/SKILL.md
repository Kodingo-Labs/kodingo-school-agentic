---
name: functional-docs
description: Genera documentación funcional del microservicio para negocio, Product Owner y QA (propósito, actores, casos de uso, reglas de negocio, datos, integraciones, errores visibles y glosario) sin jerga técnica. Úsala cuando se pida documentación funcional, de negocio o casos de uso del servicio.
---

# Functional docs

## Objetivo

Explicar **qué hace el servicio y por qué**, en lenguaje de negocio, para que personas no técnicas lo entiendan y QA pueda derivar casos de prueba.

## Entradas

- `docs/migracion/02-api-y-logica.md` (fuente principal) y `01-arquitectura.md`.
- Si no existen, ejecuta primero `service-discovery`.

## Restricciones

- **Sin nombres de clases, anotaciones ni código** en el cuerpo del documento. La trazabilidad técnica va solo en el anexo.
- No inventar reglas: toda regla debe derivar del código o de `02-api-y-logica.md`. Lo inferido se marca como `[SUPUESTO]` y va a "Preguntas para negocio".

## Estructura del documento

1. **Propósito del servicio**: qué problema de negocio resuelve (3-5 líneas).
2. **Actores y consumidores**: quién usa el servicio (sistemas, canales, usuarios) y para qué.
3. **Capacidades**: lista de lo que el servicio permite hacer.
4. **Casos de uso**: uno por capacidad, con este formato:
   - `CU-01 – Nombre`
   - Actor, disparador, precondiciones.
   - Flujo principal (pasos numerados).
   - Flujos alternativos y de excepción.
   - Reglas de negocio aplicadas (referencias `RN-xx`).
   - Resultado / postcondiciones.
   - Diagrama `flowchart` si el flujo tiene más de 3 decisiones.
5. **Catálogo de reglas de negocio**: `RN-01`, descripción, ejemplo concreto y casos de uso donde aplica.
6. **Información que maneja**: entidades de negocio y sus datos en lenguaje de negocio (no tablas).
7. **Integraciones**: con qué sistemas se comunica, qué intercambia y qué pasa si el otro sistema falla.
8. **Mensajes y errores visibles**: qué situaciones de error puede recibir un consumidor y qué significan.
9. **Glosario** de términos de negocio.
10. **Preguntas para negocio**: supuestos por confirmar.
11. **Anexo de trazabilidad**: caso de uso → endpoint(s) → regla(s).

## Entregables

- `docs/migracion/06-documentacion-funcional.md`.

## Checklist de salida

- [ ] Cada endpoint de `02-api-y-logica.md` está cubierto por al menos un caso de uso.
- [ ] Cada regla de negocio tiene un ejemplo concreto.
- [ ] Un lector sin conocimientos técnicos entiende el documento.
