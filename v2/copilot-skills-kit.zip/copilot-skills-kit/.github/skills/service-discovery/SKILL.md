---
name: service-discovery
description: Analiza el microservicio Spring Boot actual y documenta arquitectura, dependencias, configuración, integraciones, endpoints expuestos, contratos request/response y la lógica interna de cada endpoint con explicación técnica y funcional. Úsala cuando se pida entender el repositorio, qué servicios expone, qué responde o cómo funciona un flujo.
---

# Service discovery

## Objetivo

Producir la radiografía técnica del servicio. Es la base de todas las demás skills, así que debe ser completa y trazable al código.

## Restricciones

- Solo lectura: **no modificar ningún archivo** fuera de `docs/migracion/`.
- Cada afirmación cita `ruta/Archivo.java:línea`.
- Lo no verificable se marca como `[SUPUESTO]`.

## Pasos

1. **Build y dependencias** (`pom.xml` / `build.gradle`)
   - Versión de Java, Spring Boot y Spring Cloud.
   - Dependencias directas agrupadas por tipo: web, datos, mensajería, seguridad, observabilidad, utilidades y **librerías internas/corporativas** (groupId propio de la empresa). Resalta estas últimas: son el mayor riesgo de migración.
   - Plugins de build relevantes (JaCoCo, generación de código, OpenAPI, MapStruct, Lombok).
2. **Estructura**
   - Paquetes y capas, clase `@SpringBootApplication`, estilo arquitectónico (capas, hexagonal, mezcla).
   - Diagrama Mermaid de componentes.
3. **Configuración**
   - `application*.yml|properties`, perfiles, variables de entorno y propiedades custom (`@Value`, `@ConfigurationProperties`).
   - Tabla: propiedad, dónde se usa, valor por perfil (sin secretos).
4. **Integraciones salientes**
   - Base de datos: motor, entidades, relaciones (`erDiagram`), repositorios, queries nativas/JPQL, Specifications, migraciones (Flyway/Liquibase).
   - Clientes HTTP (RestTemplate, WebClient, Feign): destino, operaciones, timeouts, reintentos.
   - Mensajería, caché, almacenamiento de archivos, schedulers (`@Scheduled`), tareas asíncronas (`@Async`).
5. **Endpoints expuestos**: por cada `@RestController` / `@Controller`:
   - Tabla resumen: método HTTP, ruta, handler, request, response, códigos HTTP, seguridad requerida.
   - Detalle: headers, path/query params, body (campos, tipos, obligatoriedad, validaciones Bean Validation) y ejemplo JSON de request y response.
6. **Lógica interna por endpoint**
   - **Técnica**: flujo controller → service → repository/cliente, con `sequenceDiagram`; transacciones (`@Transactional`, propagación, readOnly), mapeos (MapStruct/manual), efectos secundarios (escrituras, eventos, llamadas externas).
   - **Funcional**: qué necesidad de negocio resuelve y qué reglas de negocio aplica (en lenguaje no técnico).
   - Casos de error: qué excepción se lanza, cómo se traduce a HTTP y qué cuerpo de error devuelve.
7. **Aspectos transversales**: seguridad (filtros, roles, `@PreAuthorize`), manejo global de errores (`@ControllerAdvice`), filtros e interceptores, AOP, logging y correlación, observabilidad (Actuator, métricas, trazas).
8. **Contrato OpenAPI**
   - Si existe springdoc, indica cómo exportar el contrato (`/v3/api-docs`) y guárdalo.
   - Si no existe, genera `docs/migracion/openapi-actual.yaml` a partir del código y marca como `x-inferido: true` lo deducido.

## Entregables

- `docs/migracion/01-arquitectura.md`: resumen ejecutivo, stack y versiones, dependencias, estructura, configuración, integraciones, transversales, diagramas y preguntas abiertas.
- `docs/migracion/02-api-y-logica.md`: catálogo de endpoints, detalle por endpoint (contrato, lógica técnica, lógica funcional, errores) y preguntas abiertas.
- `docs/migracion/openapi-actual.yaml`.

## Checklist de salida

- [ ] Todos los controllers del proyecto aparecen en el catálogo (verificar con búsqueda de `@RestController`, `@Controller` y `@RequestMapping`).
- [ ] Toda integración externa tiene destino, protocolo y manejo de errores.
- [ ] Las librerías internas están listadas explícitamente.
- [ ] Cada endpoint tiene explicación técnica **y** funcional.
