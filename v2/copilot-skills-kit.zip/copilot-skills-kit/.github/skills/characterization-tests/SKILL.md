---
name: characterization-tests
description: Incrementa los tests unitarios y crea tests de caracterización/contrato que congelan el comportamiento actual del servicio antes de migrarlo a Quarkus, usando tests portables sin contexto de Spring. Úsala cuando se pida aumentar cobertura, escribir unit tests o crear una red de seguridad para la migración.
---

# Characterization tests

## Objetivo

Crear una red de seguridad que **sobreviva a la migración**: los mismos tests deben pasar en la versión Spring y en la versión Quarkus. No se trata de subir cobertura por subirla, sino de fijar el comportamiento observable actual.

## Entradas

- `docs/migracion/01-arquitectura.md` y `docs/migracion/02-api-y-logica.md` (si no existen, ejecuta primero `service-discovery`).

## Principios

1. **Portabilidad**: un test que depende del contexto de Spring se pierde al migrar. No escribirlo.
2. **Caracterizar, no corregir**: el test afirma lo que el código hace hoy. Si parece un bug, el test lo refleja, se marca con `// [BUG?]` y se registra en el plan; no se corrige.
3. **Priorizar por riesgo**: primero la lógica de negocio y lo que más cambia en la migración.
4. **No modificar `src/main`**. Si una clase no es testeable sin cambiarla, se registra como deuda para `tech-debt-review`.

## Pasos

1. **Línea base**
   - Ejecuta la suite actual y registra resultados y cobertura (JaCoCo: línea y rama, por paquete).
   - Si JaCoCo no está configurado, **propón** el cambio al `pom.xml`/`build.gradle` y pide confirmación antes de aplicarlo.
   - Clasifica los tests existentes: portables / dependientes de Spring (se perderán al migrar).
2. **Priorización**: arma una matriz de clases con criticidad de negocio, complejidad y cobertura actual. Orden sugerido:
   1. Servicios con reglas de negocio.
   2. Validadores y reglas de cálculo.
   3. Mappers (entidad ↔ DTO).
   4. Traducción de excepciones a respuestas de error.
   5. Utilidades con lógica.
3. **Tipo A: tests unitarios puros** (`src/test/java/.../unit` o junto a la clase)
   - `@ExtendWith(MockitoExtension.class)`, `@Mock` e instanciación por constructor.
   - Si la clase usa inyección por campo, usa `@InjectMocks` y regístralo como deuda.
   - Cubrir: camino feliz, límites, nulos/vacíos, cada rama de error y cada regla de negocio de `02-api-y-logica.md`.
   - Test data builders o fixtures reutilizables; nada de datos mágicos repetidos.
4. **Tipo B: tests de contrato de caja negra** (paquete `contract`, `@Tag("contract")`)
   - RestAssured contra el servicio en ejecución.
   - URL base configurable: `-Dcontract.baseUrl=http://localhost:8080` (por defecto localhost).
   - Por endpoint: status code, headers relevantes, estructura y valores del body, formato de fechas y nulos, y **cuerpo de error** en cada caso de fallo.
   - Dependencias externas simuladas con WireMock; base de datos con Testcontainers o datos semilla documentados.
   - Estos tests se ejecutarán contra la versión Quarkus en `migration-parity-check`.
5. **Medición final**: cobertura antes y después, y lista de brechas pendientes.

## Prohibido en tests nuevos

`@SpringBootTest`, `@WebMvcTest`, `@DataJpaTest`, `@MockBean`, `@SpyBean`, `SpringExtension`, `MockMvc`, `TestRestTemplate`, `ReflectionTestUtils` (salvo justificación escrita).

## Convenciones

- Nombre: `metodo_escenario_resultadoEsperado`.
- `// given` / `// when` / `// then`.
- Un comportamiento por test; aserciones con AssertJ.

## Entregables

- Tests en `src/test/java`.
- `docs/migracion/03-plan-tests.md`: línea base, matriz de priorización, tests creados por clase/endpoint, cobertura antes/después, tests existentes no portables, lista `[BUG?]`, clases no testeables (enlazadas a deuda) y cómo ejecutar cada suite.

## Checklist de salida

- [ ] Todos los tests nuevos pasan en la versión actual.
- [ ] Ningún test nuevo usa anotaciones prohibidas.
- [ ] Cada endpoint de `02-api-y-logica.md` tiene al menos un test de contrato de éxito y uno por cada error documentado.
- [ ] La suite de contrato corre cambiando solo `contract.baseUrl`.
