---
name: tech-debt-review
description: Revisa la deuda técnica del microservicio aplicando Clean Code, SOLID y patrones de diseño (incluidos patrones avanzados cuando apliquen) y clasifica cada hallazgo según convenga resolverlo antes, durante o después de la migración a Quarkus. Úsala cuando se pida revisar deuda técnica, calidad de código, refactors o buenas prácticas.
---

# Tech debt review

## Objetivo

Identificar y priorizar la deuda técnica **en función de la migración**. Una lista infinita de mejoras no sirve; cada hallazgo debe indicar cuándo conviene atacarlo.

## Entradas

- `docs/migracion/01-arquitectura.md` y `docs/migracion/02-api-y-logica.md`.
- `docs/migracion/03-plan-tests.md` (clases no testeables), si existe.

## Restricciones

- Solo análisis: no modificar código.
- No recomendar un patrón sin explicar el problema concreto que resuelve en **este** código. Si la solución simple basta, recomiéndala.

## Categorías a revisar

1. **Clean Code**: nombres, métodos largos (> 30 líneas), clases grandes (> 300 líneas), parámetros excesivos (> 4), duplicación, código muerto, números mágicos, comentarios obsoletos, anidamiento profundo, manejo de excepciones (catch vacíos, `Exception` genérica, excepciones para control de flujo).
2. **SOLID**
   - SRP: servicios "dios" o controllers con lógica.
   - OCP: `switch`/`if` por tipo que crecen con cada caso nuevo.
   - LSP: herencia que rompe contratos.
   - ISP: interfaces enormes.
   - DIP: dominio que depende de infraestructura o del framework.
3. **Diseño y arquitectura**: fuga de capas (entidades JPA expuestas en la API, `ResponseEntity` en servicios), modelo anémico con lógica dispersa, acoplamiento a integraciones externas sin abstracción, transacciones mal delimitadas, dependencias circulares.
4. **Olores que afectan la migración** (prioridad alta):
   - Inyección por campo (`@Autowired` en atributos).
   - Estado estático mutable, `ThreadLocal`, singletons manuales.
   - Beans condicionales en runtime (`@Conditional*`, `@Profile` con lógica).
   - AOP custom (`@Aspect`), `BeanPostProcessor`, `ApplicationContext.getBean`.
   - APIs de Spring dentro del dominio (Spring Data, `Environment`, eventos de Spring).
   - Reflexión o carga dinámica de clases.
   - Uso de `javax.*` (si es Spring Boot 2).
5. **Seguridad y robustez**: validación de entrada, datos sensibles en logs, timeouts y reintentos ausentes en clientes externos, recursos no cerrados.
6. **Rendimiento**: consultas N+1, `FetchType.EAGER` indiscriminado, paginación ausente, llamadas bloqueantes en serie que podrían paralelizarse.

## Patrones a considerar (solo si aplican)

Strategy (reemplazar condicionales por tipo), Specification (reglas de negocio combinables), Template Method / Chain of Responsibility (flujos de validación), Decorator (comportamiento transversal sin AOP), Adapter / Anti-Corruption Layer (aislar integraciones externas), Ports & Adapters / Hexagonal (desacoplar el dominio del framework, que además facilita la migración), Factory / Builder (construcción compleja), Outbox (consistencia entre BD y mensajería).

## Formato de cada hallazgo

| Campo | Contenido |
|---|---|
| ID | `TD-001` |
| Ubicación | `ruta/Archivo.java:línea` |
| Categoría | Clean Code / SOLID-SRP / Migración / ... |
| Descripción | Qué pasa y por qué es un problema |
| Impacto | Mantenibilidad, riesgo de bug, bloqueo de migración, rendimiento |
| Severidad | Crítica / Alta / Media / Baja |
| Esfuerzo | S (< 1 d) / M (1-3 d) / L (> 3 d) |
| **Momento** | **ANTES** (bloquea o encarece la migración) / **DURANTE** (se reescribe igual) / **DESPUÉS** (no afecta la migración) |
| Recomendación | Cambio concreto y patrón, si aplica, con un antes/después breve en pseudocódigo |

## Entregables

- `docs/migracion/04-deuda-tecnica.md`: resumen ejecutivo (conteo por severidad y momento), top 10 priorizado, hallazgos completos agrupados por momento, métricas (tamaño de clases y métodos, complejidad aproximada) y recomendaciones de estándares para el equipo.

## Checklist de salida

- [ ] Todo hallazgo tiene ubicación y momento.
- [ ] Los hallazgos ANTES están justificados por su impacto en la migración.
- [ ] Ningún patrón recomendado sin problema concreto.
