# Instrucciones del repositorio para GitHub Copilot

## Contexto

Este repositorio contiene un microservicio Java construido con **Spring Boot** que será **migrado a Quarkus** y **desplegado en Azure** (destino: `{{AZURE_TARGET}}`).
La migración de código la ejecuta un agente migrador; las skills de `.github/skills/` preparan el análisis, la red de seguridad de tests, el plan y la verificación.

## Fases del trabajo

| Fase | Objetivo | Skills | ¿Se modifica `src/main`? |
|---|---|---|---|
| 1. Análisis | Entender arquitectura, API, lógica y deuda | `service-discovery`, `tech-debt-review`, `functional-docs` | **No** |
| 2. Red de seguridad | Congelar el comportamiento actual con tests portables | `characterization-tests` | **No** (solo `src/test`) |
| 3. Plan de migración | Inventario Spring → Quarkus y riesgos | `quarkus-migration-assessment` | **No** |
| 4. Migración | Ejecutada por el agente migrador | — | Sí |
| 5. Verificación | Demostrar equivalencia funcional | `migration-parity-check` | No |
| 6. Despliegue | Preparar y desplegar en Azure | `azure-deploy-readiness` | Solo artefactos de despliegue |

## Reglas generales (aplican siempre)

- **Evidencia obligatoria**: todo hallazgo o afirmación sobre el código debe citar `ruta/Archivo.java:línea`.
- **No inventar**: si algo no se puede verificar en el código, márcalo como `[SUPUESTO]` y agrégalo a "Preguntas abiertas".
- **Posibles bugs**: si el comportamiento actual parece incorrecto, documéntalo como `[BUG?]`; no lo corrijas durante las fases 1-3.
- **Secretos**: nunca copies valores de contraseñas, tokens o cadenas de conexión en la documentación; referencia solo el nombre de la propiedad.
- **Entregables**: todos los documentos se guardan en `docs/migracion/` con el prefijo numérico indicado en cada skill.
- **Idioma**: documentación en español; identificadores de código, nombres de tests y commits en inglés.
- **Diagramas**: usar Mermaid (`flowchart`, `sequenceDiagram`, `classDiagram`, `erDiagram`).
- Antes de ejecutar una skill, lee los entregables previos de `docs/migracion/` de los que depende.

## Estándares de código

- Clean Code: nombres expresivos, funciones pequeñas con una sola responsabilidad, sin números mágicos, sin código muerto ni comentarios que repiten el código.
- SOLID, con especial atención a SRP y DIP (el dominio no depende de frameworks).
- Inyección por **constructor**; evitar la inyección por campo.
- El dominio y los servicios no deben usar tipos web (`ResponseEntity`, `HttpServletRequest`) ni tipos del framework cuando no sea necesario.
- Aplicar un patrón solo si resuelve un problema concreto; explicar siempre cuál.

## Estándares de tests

- JUnit 5 + AssertJ + Mockito.
- Nombre: `metodo_escenario_resultadoEsperado` (por ejemplo, `calculateFee_whenAmountIsZero_returnsZero`).
- Estructura `// given` / `// when` / `// then`.
- Los tests unitarios **no levantan contexto de framework**: prohibidos `@SpringBootTest`, `@WebMvcTest`, `@DataJpaTest`, `@MockBean` y `SpringExtension` en tests nuevos.
- Los tests de contrato son de caja negra (RestAssured) con la URL base configurable, para ejecutarse contra la versión Spring y la versión Quarkus.
