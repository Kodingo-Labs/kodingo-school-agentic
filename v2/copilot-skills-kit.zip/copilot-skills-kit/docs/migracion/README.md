# Migración Spring Boot → Quarkus + despliegue en Azure

Entregables generados por las skills de GitHub Copilot (`.github/skills/`). Destino Azure: `{{AZURE_TARGET}}`.

## Orden de ejecución

```mermaid
flowchart LR
  A[service-discovery] --> B[characterization-tests]
  A --> C[tech-debt-review]
  A --> F[functional-docs]
  B --> D[quarkus-migration-assessment]
  C --> D
  D --> M((Agente migrador))
  M --> P[migration-parity-check]
  P --> Z[azure-deploy-readiness]
```

## Entregables

| # | Documento | Skill | Estado |
|---|---|---|---|
| 01 | `01-arquitectura.md` | service-discovery | ⬜ |
| 02 | `02-api-y-logica.md` + `openapi-actual.yaml` | service-discovery | ⬜ |
| 03 | `03-plan-tests.md` | characterization-tests | ⬜ |
| 04 | `04-deuda-tecnica.md` | tech-debt-review | ⬜ |
| 05 | `05-migracion-quarkus.md` | quarkus-migration-assessment | ⬜ |
| 06 | `06-documentacion-funcional.md` | functional-docs | ⬜ |
| 07 | `07-paridad.md` | migration-parity-check | ⬜ |
| 08 | `08-despliegue-azure.md` | azure-deploy-readiness | ⬜ |

## Cómo invocar una skill

En el chat de Copilot (modo agente), pide la tarea de forma explícita, por ejemplo:

> Usa la skill `service-discovery` para analizar este repositorio.

Copilot también puede cargar la skill automáticamente cuando la petición coincide con su `description`.
